<?php
/**
 * Created by PhpStorm.
 * User: red
 * Date: 16.08.16
 * Time: 15:43
 */
echo  "Hello";

